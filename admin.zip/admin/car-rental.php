<?php
    session_start();
    if(!isset($_SESSION['access']) && $_SESSION['access'] != "granted" || (time() - $_SESSION['timeout']) > 1200){
      session_destroy();
      header("LOCATION:cgi-bin.php");
    }
    $_SESSION['timeout'] = time();
    include_once("php_scripts/db_conn.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Computicket Admin Dashboard</title>
  <link rel="icon" href="../assets/img/Computicket.jpg" type="image/jpg">

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  <link rel="stylesheet" href="../css/fonts.css">
  <link rel="stylesheet" href="vendor/fontawesome/css/all.min.css">
  <link rel="stylesheet" href="../lib/sweetalerts/sweetalert.css">
  <link rel="stylesheet" href="../lib/semantic/dist/semantic.min.css">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

  <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
  <script type="text/javascript" src="js/client_processes.js"></script>
  <script src="../lib/sweetalerts/sweetalert.min.js"></script>
  <script src="../lib/sweetalerts/sweetalert.js"></script>
  
</head>

<body>

<div class="d-flex" id="wrapper">

<!-- Sidebar -->
<div class="bg-dark border-dark" id="sidebar-wrapper">
<div class="sidebar-heading" style="color:white;font-family:electra;">Compu<span style="color:red;">ticket</span></div>
  <div class="list-group list-group-flush">
    <a href="dashboard.php" class="list-group-item list-group-item-action bg-dark">Dashboard</a>
    <a href="index.php" class="list-group-item list-group-item-action bg-dark">Merchants </a>
    <a href="car-rental.php" class="list-group-item list-group-item-action bg-light">Car Rentals</a>
    <a href="buses.php" class="list-group-item list-group-item-action bg-dark">Bus & Trips</a>
    <a href="hotels.php" class="list-group-item list-group-item-action bg-dark">Hotel </a>
    <a href="events.php" class="list-group-item list-group-item-action bg-dark">Events </a>
    <a href="payments.php" class="list-group-item list-group-item-action bg-dark">Finances </a>
    <a href="accounts.php" class="list-group-item list-group-item-action bg-dark">Accounts </a>
    <a href="config.php" class="list-group-item list-group-item-action bg-dark">Configuration</a>
  </div>
</div>
<!-- /#sidebar-wrapper -->

<!-- Page Content -->
<div id="page-content-wrapper">

 
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-bottom">
        <button class="btn btn-primary btn-sm flat-field" id="menu-toggle">Extend Page</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item">
            <a  class="nav-link">Logged in as : <span style="color:red;font-family:mali-reg;">
            <?php echo strtoupper($_SESSION["fullname"])."(<span style='color:white;'>".$_SESSION['role']."</span>)";?></span></a>
            </li>
        </ul>
        </div>
    </nav>

      
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

<!-- Client Aid Modal -->



</body>

</html>
